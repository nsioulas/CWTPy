"""
CWTPy - A fast continuous wavelet transform package.
"""
__version__ = "0.1.1"
from .cwt_module import *
