"""
CWTPy - A fast continuous wavelet transform package.
"""
__version__ = "0.2.3"

from .cwt_module import *
