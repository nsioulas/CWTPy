"""
CWTPy - A fast continuous wavelet transform package.
"""
__version__ = "0.3.0"

from .cwt_module import *
