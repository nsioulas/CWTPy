"""
CWTPy - A fast continuous wavelet transform package.
"""
__version__ = "0.3.4"

from .cwt_module import *
